from discord.ext import commands
from bs4 import BeautifulSoup
from forex_python.converter import CurrencyRates, RatesNotAvailableError
from datetime import datetime
from dateutil import relativedelta
from requests import get as request
from qrcode import make as qr_make
import random
import discord
import os
import wikipedia

import embed as emb




help_command = commands.DefaultHelpCommand(
    no_category='Comandos'
)


intents = discord.Intents.default()
intents.message_content = True


bot = commands.Bot(command_prefix='$', intents=intents, help_command=help_command)


script_directory = os.path.abspath(os.path.dirname(__file__))  



@bot.command(name='meme', help='Imagen random en el chat')
async def images(ctx):
    all_files = os.listdir(f"{script_directory}/images")
    allowed_extensions = ('.png', '.jpg', '.jpeg', '.gif')

 
    all_images = [file for file in all_files if
                  file.endswith(allowed_extensions)]

 
    random_image = f"{script_directory}/images/{random.choice(all_images)}"

    await ctx.send(file=discord.File(random_image))




@bot.command(name='texto', help='manda un texto random')
async def send_random_text(ctx):
    text_file_path = f"{script_directory}/text/text.txt"

    with open(text_file_path) as file:
        lines = [line for line in file.read().splitlines()]

    lines_with_split_text = [line.split(",") for line in lines]

    random_line = random.choice(lines_with_split_text)
    random_text = random.choice(random_line)

    await emb.send_embed(ctx, title=random_text)



@bot.command(name='whatis', help='Manda un articulo de wikipedia de algo que quieras')
async def whatis(ctx, *args: str):
    if args:
        data = " ".join(args)

        try:
            article = wikipedia.summary(data, sentences=2)
            await emb.send_embed(ctx, title=data.title(), description=article)

        except (wikipedia.PageError, wikipedia.DisambiguationError):
            articles = wikipedia.search(data, results=5)

            if articles:
                articles = ", ".join(articles)
                await emb.send_embed(ctx, title=f'{data.title()} puede ser : ', description=articles)

            else:
                await emb.send_embed(ctx, title="El artículo no existe", color=0xFF0000)

    else:
        await emb.send_embed(ctx, title="Por favor escribe algo que te interese", color=0xFF0000)


@bot.command(name='qrcode', help="Te hace un codigo qr propio | !qrcode 'lo quieres en el qr' ")
async def make_qrcode(ctx, *, data: str = None):
    if data:
        qr_code = qr_make(data)  

        qr_filepath = f"{script_directory}/qr.png"  
        qr_code.save(qr_filepath) 

        await ctx.send(file=discord.File(qr_filepath))
        os.remove(qr_filepath)  

    else:
        await emb.send_embed(ctx, title='Escribe !qrcode "y aqui lo que quieres en qr"', color=0xFF0000)



@bot.command(name='Noticias', help="Envia 3 noticias")
async def send_three_news(ctx):
    url = 'https://www.bbc.com'

    url_to_news = f'{url}/news/world/'
    response = request(url_to_news)

    soup = BeautifulSoup(response.text, 'html.parser')
    get_promo_news = soup.select("[class~=gs-c-promo-heading]", href=True)
    links = []

    for counter, news in enumerate(get_promo_news):
        news_url = f'{url}{news["href"]}'

        if news_url not in links and counter <= 3:
            links.append(news_url)

        elif counter > 3:
            break

    links = "\n".join(links)
    await ctx.send(f"{links}")



@bot.command(name='pipati', help="Juega a un piedra papel o tijeras con el bot | !pipati 'tu eleccion'")
async def rpas_game(ctx, player_choice: str = None):
    if player_choice:
        choices = ("piedra", "papel", "tijeras")
        bot_choice = random.choice(choices)

        if player_choice in choices:

            if bot_choice == player_choice:
                await emb.send_embed(ctx, title="Tie", description=f"You both choose {bot_choice}", color=0x808080)

            elif bot_choice == "piedra" and player_choice == "papel" or \
                    bot_choice == "tijeras" and player_choice == "piedra" or \
                    bot_choice == "papel" and player_choice == "tijeras":

                await emb.send_embed(ctx,
                                     title="Ganaste! :tada:",
                                     description=f"El bot escogió {bot_choice}",
                                     color=0x00ff00)

            elif bot_choice == "piedra" and player_choice == "tijeras" or \
                    bot_choice == "papel" and player_choice == "piedra" or \
                    bot_choice == "tijeras" and player_choice == "papel":

                await emb.send_embed(ctx, title="Bot gana", description=f"El bot escogió {bot_choice}", color=0xb41b1b)

        else:
            await emb.send_embed(ctx, title="Por favor elige solo un piedra, papel o tijeras", color=0xFF0000)

    else:
        await emb.send_embed(ctx, title="Por favor escribe !pipati 'lo que elegiste'", color=0xFF0000)



@bot.command(name='númerodelasuerte', help="Envia un número random | !random de 'número' a 'número' ")
async def choose_random_number(ctx, *arg):
    if arg:
        try:
            start_number, end_number = int(arg[1]), int(arg[3])

            if arg[0] == "de" and arg[2] == "a" and start_number < end_number:
                random_number = random.randrange(start_number, end_number + 1)

                await emb.send_embed(ctx, title=f'Tú número {random_number}')

            elif start_number >= end_number:
                await emb.send_embed(ctx, title="Asegúrate que el primer número sea menor al segundo", color=0xFF0000)

            else:
                await emb.send_embed(ctx, title='Por favor escriba: !random de "número" a "número"',
                                     color=0xFF0000)

        except ValueError:
            await emb.send_embed(ctx, title="Solo números son aceptados por mi", color=0xFF0000)

        except IndexError as e:
            if str(e) == "tuple index out of range":
                await emb.send_embed(ctx, title='Por favor escriba: !random de "número" a "número"',
                                     color=0xFF0000)

    else:
        await emb.send_embed(ctx, title='Por favor escriba: !random de "número" a "número"',
                             color=0xFF0000)



@bot.command(name='numescondido', help='Jugar a adivinar el número')
async def guess_the_number(ctx):
    await emb.send_embed(ctx, title="Adivina un número entre 1 - 100",
                         description='Escriba el número en el chat. Si quieres salir escribe "salir"')

    random_number = random.randrange(1, 101)
    win = False
    attempts = 1

    while not win:
        try:
            message = await bot.wait_for('message', timeout=15,
                                         check=lambda m: m.author == ctx.author and m.channel.id == ctx.channel.id)

            if message.content == "salir":
                await emb.send_embed(ctx, title="Gracias por jugar!")
                break

            user_guess = int(message.content)

            if user_guess == random_number:
                win = True

                await emb.send_embed(ctx,
                                     title="Enhorabuena!",
                                     description=f"Has encontrado el número con {attempts} intentos! :tada:",
                                     color=0x00ff00)


            elif user_guess > random_number:
                attempts += 1
                await emb.send_embed(ctx, title="El número es menor")
                continue

            elif user_guess < random_number:
                attempts += 1
                await emb.send_embed(ctx, title='El número es mayor')
                continue

        except ValueError:
            await emb.send_embed(ctx, title='Solo acepto números', color=0xFF0000)
            continue


        except TimeoutError:
            await emb.send_embed(ctx, title='Se le ha acabado el tiempo', color=0xFF0000)




@bot.command(name='convertir', help='Convertir una moneda en otra | !convertir de "1moneda" a "2moneda" "cantidad"')
async def convert_currency(ctx, from_currency: str = None, to_currency: str = None, amount: str = None):
    try:
        if from_currency and to_currency and amount:

            from_currency, to_currency = from_currency.upper(), to_currency.upper()

            amount = float(amount)

            currency_rates = CurrencyRates()

            convert_result = currency_rates.convert(from_currency, to_currency, amount)

            result = round(convert_result, 2)

            await emb.send_embed(ctx, title=f"{amount} {from_currency} = {result} {to_currency}")

        else:
            await emb.send_embed(ctx, title='Escribr !convertir de "1moneda" a "2moneda" "cantidad"',
                                 color=0xFF0000)

    except ValueError:
        await emb.send_embed(ctx, title='Entraste mal la cantidad', color=0xFF0000)

    except RatesNotAvailableError:
        await emb.send_embed(ctx, title='No se ha podido usar esta moneda', color=0xFF0000)



@bot.listen('on_message')
async def check_for_banned_words(msg):
    message_content = msg.content.casefold()

    words_file_path = f"{script_directory}/lista de palabras/palabras.txt"
    warn_message = f"{msg.author.mention} ha sido advertido"

    with open(words_file_path) as file:
        banned_words_lines = [line for line in file.read().splitlines()]

    banned_words = [line.split(",") for line in banned_words_lines]
    banned_words = [word for lines in banned_words for word in lines]

    user_banned_message = [word for word in banned_words if word in message_content]

    if any(user_banned_message):
        await msg.channel.send(warn_message) and await msg.delete()



@bot.listen('on_message')
async def chat_with_bot(msg):
    message_content = msg.content.casefold()

    greetings = ("hola", "holi", "que hay", "que onda")
    name_to_react = ("bot", "robot")
    how_are_you_react = ("cómo estas?", "cómo le va?", "todo bien?", "cómo estás hoy?")
    how_old_are_you_react = ("cuámtos años tienes?", "cuál es tu edad?")

    user_greeting_msg = [greeting in message_content for greeting in greetings]
    user_name_to_react_msg = [name in message_content for name in name_to_react]
    user_how_are_you_react_msg = [x in message_content for x in how_are_you_react]
    user_how_old_msg = [x in message_content for x in how_old_are_you_react]
    user_bad_mood_msg = ("mal", "no muy bien")
    user_good_mood_msg = ("bien", "ok", "bastante bien", "mas o menos", "muy bien")

    random_greeting = random.choice(greetings)
    random_greeting = random_greeting.title()


    if any(user_greeting_msg) and any(user_name_to_react_msg):
        await msg.channel.send(f"{random_greeting} {msg.author.name} :wave:")


    if any(name_to_react) and any(user_how_are_you_react_msg):
        await msg.channel.send(f"Yo bien, y tu ?")

        response = await bot.wait_for('message', timeout=30,
                                      check=lambda m: m.author == msg.author and m.channel.id == msg.channel.id)

        if response.content in user_bad_mood_msg:
            await msg.channel.send(
                f"Oh lo siento :confused:\n"
                f"Podemos jugar algo divertido usa !help para más info :blush:")

        elif response.content in user_good_mood_msg:
            await msg.channel.send(f"Me hace feliz escucharlo :relaxed:")

    if any(user_name_to_react_msg) and any(user_how_old_msg):
        bot_created = datetime(year=2022, month=8, day=5)
        current_date = datetime.utcnow()
        bot_created, current_date = bot_created.date(), current_date.date()
        age = relativedelta.relativedelta(current_date, bot_created)

        await msg.channel.send(
            f"Fui creado en {bot_created}\nSo tecnicamente tengo {age.years} años y {age.months} meses "
            f"con {age.days} días :smile:")



@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await emb.send_embed(ctx,
                             title="Comando no encontrado !",
                             description="Si quieres encontrar los comandos usa !help.",
                             color=0xFF0000)



if __name__ == "__main__":
    bot.run("MTMzNTI5NjE3MzAxNTMwNjI5MQ.G1fAZ0.fnzaQ_4XG984l60100cCzUQkjL6DDO1nMZLMb0")
